export class Product {

    categoryId:number;
    subcategoryId:number;
    price:number;
    itemName:string;
    description:string;
    stockNumber:number;
    remarks:string;
   


}