import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart, ViewCart } from './cart';
import { Item } from './items';
import { Transaction } from './Transaction';
import { ApiResponse } from './api.response';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
 

  private baseUrl = 'http://localhost:8385/items';
  private baseUrl1 = 'http://localhost:8386/cart';
  
  private baseUrl2='http://localhost:8910/token/generate-token';
  private baseUrl3='http://localhost:8909/token/generate-token';

  constructor(private http: HttpClient) { }

  createBuyer(buyer: Object): Observable<Object>{

    return this.http.post(`http://localhost:8386/buyer/addBuyer`,buyer);
  }
  createSeller(seller: Object): Observable<Object>{
    console.log(seller);
    return this.http.post(`http://localhost:8385/addseller`,seller);
  }

  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/getitems/${itemname}`);
  }
  addToCart(cart:Cart):Observable<any> {
  
  
    return this.http.post(`http://localhost:8386/cart/addToCart/1`,cart);
  }
  addItem(Item:object): Observable<any>{

    console.log(Item);
    return this.http.post(`http://localhost:8385/items/addItem/1`,Item);
  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8386/cart/1/getAll`);

}
updateCartItems(cartId:number,cart:ViewCart):Observable<any>{
  return this.http.put(`${this.baseUrl1}/updatecart/${cartId}`,cart);
}
deleteCartItem(cartId:number):Observable<any>{
  console.log("servivedelete"+cartId);
  return this.http.delete(`http://localhost:8386/cart/deleteById/${cartId}`);
}
CheckoutCart(transaction:Transaction): Observable<any> {
  
  return this.http.post(`http://localhost:8386/cart/checkout/1`,transaction);
  window.alert("checkout done successfully");
}
emptycart(): Observable<void> {
  
  return this.http.delete<void>(`http://localhost:8386/cart/deleteAllCart/1`);
}
login(loginPayload:object): Observable<ApiResponse> {
return this.http.post<ApiResponse>(`${this.baseUrl2}`,loginPayload);
}
buyerlogin(loginPayload:object): Observable<ApiResponse> {
  return this.http.post<ApiResponse>(`${this.baseUrl3}`,loginPayload);
  }
}


