import { Component, OnInit } from '@angular/core';
import { Cart, ViewCart } from '../cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {



  disCart:Cart[];
  itemId:number;
  cart:Cart;
  cost: number;
  viewcart:ViewCart= new ViewCart();
  success:string;
  constructor(private displaycart:ProductService) { }

  ngOnInit(): void {


    this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
  }

  delete(j:number){
    console.log("inside delete");
    console.log(j);
    this.displaycart.deleteCartItem(j).subscribe(()=>{console.log("item deleted");
    },(error)=>console.log(error));

    this.reloadcartItems();
}
DeleteAll(){
  this.displaycart.emptycart().subscribe(
  () =>console.log("Delete All Items"),
  (error) =>console.log(error));

}
  reloadcartItems() {
    this.displaycart.displayCartItems().subscribe(disCart=>{console.log("mark"+JSON.stringify(disCart));
    this.disCart=disCart})
  }
incrementQty(cartview:ViewCart,id:number){
  this.cost=cartview.price;
   cartview.quantity+=1
   if(cartview.quantity!=1){
     cartview.total=cartview.quantity*this.cost;
     console.log(cartview);
     console.log("Quantity"+cartview.quantity+"\nCartId:"+cartview.cartItemId);
     this.displaycart.updateCartItems(id,cartview).subscribe(view=>this.viewcart=view); 
   }
   
}

decrementQty(cartview:ViewCart,id:number){
  this.cost=cartview.price;
  console.log(cartview.price);
   
   if(cartview.quantity!=1){
     cartview.quantity-=1
     cartview.total=cartview.quantity*this.cost;
     console.log(cartview);
     console.log(cartview.quantity,cartview.cartItemId);
     this.displaycart.updateCartItems(id,cartview).subscribe(view=>this.viewcart=view); 
   }
   
}

}
