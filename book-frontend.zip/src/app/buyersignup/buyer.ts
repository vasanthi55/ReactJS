export class Buyer
{
	 userName:String ;
	 password:String 
	  email:String ;
	 mobileNumber:number;
     createDateItem:String;
}