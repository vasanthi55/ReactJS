export class Cart {
 
 cartId:number;
 itemId:number;
 quantity:number;
 price:number;
 description:String;
}
export class ViewCart{
    [x:string]: number;
    cartId:number;
    cartItemId:number;
    itemId:number;
    quantity:number;
    price:number;
    total:number;
}