import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { AdditemComponent } from './additem/additem.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { ProductService } from './product.service';
import { TokenInterceptor } from './interceptor';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    DisplaycartComponent,
    SearchproductComponent,
    BuyersignupComponent,
    SellersignupComponent,
    AdditemComponent,
    CheckoutComponent,
    SellerloginComponent,
    BuyerloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule  
  ],
  providers: [ProductService,{provide:HTTP_INTERCEPTORS,
  useClass: TokenInterceptor,
  multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
