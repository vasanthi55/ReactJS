module.exports={
    MONGODB_URL: process.env.MONGODB_URL || 'mongodb://localhost/bookstore',
    JWT_SECRET: process.env.JWT_SECRET || 'somethingsecret'
}